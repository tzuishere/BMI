import UIKit
import Foundation

struct BmiInfo {
    let height: Double
    let weight: Double
}


class ResultViewController: UIViewController
{
    //var height: Double!
    //var weight: Double!
    var bmiInfo:BmiInfo!
    
    @IBOutlet weak var bmiLabel: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        updateUI()
    }
    
    //BMI值計算公式: BMI = 體重(公斤) / 身高2(公尺2).
    func updateUI()
    {
        let heighMeter = bmiInfo.height / 100
        let bmi = bmiInfo.weight / ( heighMeter * heighMeter )
        return bmiLabel.text = String(format: "%.2f", bmi)
    }
    
    
}
