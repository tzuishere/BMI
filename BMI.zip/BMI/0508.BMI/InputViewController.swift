import UIKit

class InputViewController: UIViewController
{
    @IBOutlet weak var heightTextField: UITextField!
    @IBOutlet weak var weightTextField: UITextField!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    //shouldPerformSegue：用於決定是否應該執行特定的segue至目標視圖控制器
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool
    {   //檢查兩個文本欄位中的內容，確保它們都可以轉換為Double的數值
        //使用ptional binding確保文本能夠成功轉換為Double類型。 這種方式可避免在內容為nil或無法轉換為Double時的強制解包錯誤
        if let heightText = heightTextField.text,
           let weightText = weightTextField.text,
           let _ = Double(heightText),
           let _ =  Double(weightText)
        {
            return true
        }
        else{
            return false
        }
    }
    

    @IBSegueAction func showResult(_ coder: NSCoder) -> ResultViewController?
    {
        
        let controller = ResultViewController(coder: coder)
        //controller?.height = Double(heightTextField.text!) ?? 0
        //controller?.weight = Double(weightTextField.text!) ?? 0
        let doubleHeight = Double(heightTextField.text!) ?? 0
        let doubleWeight = Double(weightTextField.text!) ?? 0
        controller?.bmiInfo = BmiInfo(height: doubleHeight, weight: doubleWeight)
        return controller
    }
}







//底線_ 是一種慣用的命名方式，用於表示一個不需要使用的變數，以便讓程式碼更加清晰和易讀
